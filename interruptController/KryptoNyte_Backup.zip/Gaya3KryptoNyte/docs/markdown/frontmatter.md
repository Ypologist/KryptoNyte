---
Title: AHB-Lite Platform-Level Interrupt Controller (PLIC)
Category: Datasheet
Author: Roa Logic
---
# AHB-Lite Platform-Level Interrupt Controller (PLIC) Datasheet

## Contents
